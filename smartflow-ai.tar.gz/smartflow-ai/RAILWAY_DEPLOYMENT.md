# 🚂 Railway Deployment Guide

Complete guide to deploy SmartFlow AI on Railway.app

## Prerequisites

- GitHub account
- Railway account (free tier available)
- OpenAI API key

## Step 1: Push to GitHub (2 minutes)

```bash
# Initialize git repository
cd smartflow-ai
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - SmartFlow AI Platform"

# Create repository on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/smartflow-ai.git
git branch -M main
git push -u origin main
```

## Step 2: Create Railway Project (1 minute)

1. Go to [railway.app](https://railway.app)
2. Sign in with GitHub
3. Click **"New Project"**
4. Select **"Deploy from GitHub repo"**
5. Choose your `smartflow-ai` repository
6. Railway will automatically detect the Dockerfile

## Step 3: Add PostgreSQL Database (1 minute)

1. In your Railway project dashboard
2. Click **"New"** button
3. Select **"Database"** → **"PostgreSQL"**
4. Railway creates a database automatically
5. **DATABASE_URL** is automatically linked to your app

## Step 4: Configure Environment Variables (2 minutes)

In your Railway project, click on your service, then go to **Variables**:

### Required Variables

```env
# Database (automatically set by Railway)
DATABASE_URL=postgresql://...

# Server Configuration
NODE_ENV=production
PORT=3000
FRONTEND_URL=https://smartflow-ai-production.up.railway.app

# AI Provider (REQUIRED)
OPENAI_API_KEY=sk-proj-your-key-here

# AI Settings
DEFAULT_AI_PROVIDER=openai
DEFAULT_AI_MODEL=gpt-3.5-turbo
DEFAULT_AI_TEMPERATURE=0.7
DEFAULT_AI_MAX_TOKENS=500

# Business Defaults
DEFAULT_BUSINESS_NAME=Your Business Name
DEFAULT_BUSINESS_INDUSTRY=Your Industry
```

### Optional Variables

```env
# Alternative AI Providers
GEMINI_API_KEY=your-gemini-key
OPENROUTER_API_KEY=your-openrouter-key

# Logging
LOG_LEVEL=info
```

## Step 5: Deploy! (Automatic)

Railway will automatically:
1. ✅ Build the Docker image
2. ✅ Install dependencies
3. ✅ Generate Prisma client
4. ✅ Run database migrations
5. ✅ Start the application

Watch the deployment logs in Railway dashboard.

## Step 6: Get Your URL (1 minute)

1. Click on your service in Railway
2. Go to **"Settings"** tab
3. Under **"Networking"**, click **"Generate Domain"**
4. Railway provides a public URL like:
   `smartflow-ai-production.up.railway.app`

## Step 7: Update Environment (1 minute)

Update the **FRONTEND_URL** variable with your Railway URL:

```env
FRONTEND_URL=https://your-app-name.up.railway.app
```

Railway will automatically redeploy.

## Step 8: Connect WhatsApp! (1 minute)

1. Visit your Railway URL
2. Navigate to **WhatsApp** page
3. Scan QR code with WhatsApp on your phone
4. ✅ Connected! Ready to receive messages

## 🎉 You're Live!

Your WhatsApp AI automation platform is now running in production!

## Monitoring & Logs

### View Logs
1. Go to Railway dashboard
2. Click on your service
3. View **Deployments** tab
4. Click **View Logs**

### Check Health
Visit: `https://your-app.railway.app/health`

Should return:
```json
{
  "status": "healthy",
  "timestamp": "...",
  "uptime": 123,
  "environment": "production"
}
```

## Database Management

### Access Database
1. Railway dashboard → PostgreSQL service
2. Click **"Connect"** tab
3. Copy connection string
4. Use with Prisma Studio or any PostgreSQL client

### Prisma Studio
```bash
# Locally, with Railway database
DATABASE_URL="postgresql://..." npx prisma studio
```

## Troubleshooting

### WhatsApp Won't Connect

**Problem:** QR code not appearing

**Solution:**
1. Check Railway logs for Puppeteer errors
2. Verify Chromium is installed (it's in Dockerfile)
3. Restart the service in Railway

**Problem:** Session keeps disconnecting

**Solution:**
1. Check if service is sleeping (upgrade to prevent)
2. Verify session directory is persistent
3. Check Railway logs for errors

### Database Issues

**Problem:** Migration errors

**Solution:**
```bash
# Reset database (CAREFUL - deletes all data)
# In Railway PostgreSQL service, click "Reset"
# App will auto-migrate on next deploy
```

**Problem:** Connection timeout

**Solution:**
1. Verify DATABASE_URL is correct
2. Check Railway PostgreSQL is running
3. Restart both services

### Deployment Fails

**Problem:** Build errors

**Solution:**
1. Check Railway build logs
2. Verify Dockerfile syntax
3. Ensure all dependencies in package.json

**Problem:** Out of memory

**Solution:**
1. Upgrade Railway plan (Hobby plan recommended)
2. Reduce concurrent operations
3. Optimize Prisma queries

## Performance Optimization

### Recommended Railway Plan
- **Starter**: Free (good for testing)
- **Hobby**: $5/month (recommended for production)
- **Pro**: $20/month (high traffic)

### Database Optimization
```prisma
// Already implemented in schema:
// - Indexes on frequently queried fields
// - Foreign key constraints
// - Proper cascade deletes
```

### Scaling Tips
1. Use Railway's auto-scaling (Hobby+ plan)
2. Add Redis for session caching (future)
3. Use connection pooling
4. Monitor database query performance

## Custom Domain (Optional)

1. Railway dashboard → Your service
2. Settings → **Networking**
3. Add **Custom Domain**
4. Follow DNS configuration instructions
5. SSL is automatic!

## Backup Strategy

### Automated Backups
Railway Pro plan includes automatic PostgreSQL backups.

### Manual Backup
```bash
# Export database
pg_dump DATABASE_URL > backup.sql

# Import later
psql DATABASE_URL < backup.sql
```

## Cost Estimation

### Free Tier
- ✅ 500 hours/month
- ✅ Shared resources
- ✅ Perfect for testing

### Hobby Plan ($5/month)
- ✅ Always online
- ✅ Better performance
- ✅ Recommended for production

### Pro Plan ($20/month)
- ✅ Auto-scaling
- ✅ Automated backups
- ✅ Priority support
- ✅ High traffic handling

## Security Checklist

- ✅ Environment variables (not in code)
- ✅ HTTPS enabled (automatic on Railway)
- ✅ Database password secured
- ✅ CORS configured
- ✅ Helmet.js security headers
- ✅ Rate limiting implemented
- ⚠️ Add authentication for admin panel (future)

## Support & Help

### Railway Issues
- [Railway Docs](https://docs.railway.app)
- [Railway Discord](https://discord.gg/railway)
- [Railway Status](https://status.railway.app)

### Application Issues
- Check server logs in Railway
- Review README.md troubleshooting
- Check WhatsApp session status

## Next Steps

1. ✅ Connect WhatsApp
2. ✅ Test with a message
3. ✅ Configure AI settings
4. ✅ Customize system prompt
5. ✅ Monitor analytics
6. ✅ Set up custom domain (optional)
7. ✅ Add team members (optional)

---

**Your WhatsApp AI platform is production-ready! 🚀**

Need help? Check the main README.md or Railway documentation.
