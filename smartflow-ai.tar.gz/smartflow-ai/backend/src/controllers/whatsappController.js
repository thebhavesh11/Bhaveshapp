const { getWhatsAppStatus, getCurrentQR } = require('../services/whatsapp/whatsappService');
const { prisma } = require('../services/database/prismaClient');
const { logger } = require('../utils/logger');

/**
 * Get WhatsApp connection status
 */
async function getStatus(req, res) {
  try {
    const status = await getWhatsAppStatus();
    res.json(status);
  } catch (error) {
    logger.error('Error getting WhatsApp status:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get current QR code
 */
async function getQRCode(req, res) {
  try {
    const session = await prisma.whatsAppSession.findFirst({
      where: { sessionId: 'default' }
    });

    if (session?.isConnected) {
      return res.json({
        isConnected: true,
        phoneNumber: session.phoneNumber,
        message: 'WhatsApp is already connected'
      });
    }

    if (session?.qrCode) {
      return res.json({
        isConnected: false,
        qrCode: session.qrCode,
        message: 'Scan this QR code with WhatsApp'
      });
    }

    res.json({
      isConnected: false,
      message: 'QR code not yet generated. Please wait...'
    });

  } catch (error) {
    logger.error('Error getting QR code:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get session info
 */
async function getSessionInfo(req, res) {
  try {
    const session = await prisma.whatsAppSession.findFirst({
      where: { sessionId: 'default' }
    });

    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    res.json({
      isConnected: session.isConnected,
      phoneNumber: session.phoneNumber,
      lastConnected: session.lastConnected,
      hasQR: !!session.qrCode
    });

  } catch (error) {
    logger.error('Error getting session info:', error);
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  getStatus,
  getQRCode,
  getSessionInfo
};
