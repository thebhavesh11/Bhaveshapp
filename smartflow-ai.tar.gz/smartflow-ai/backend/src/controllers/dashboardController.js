const { prisma } = require('../services/database/prismaClient');
const { logger } = require('../utils/logger');

/**
 * Get dashboard metrics
 */
async function getDashboardMetrics(req, res) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Get today's metrics
    const todayMetrics = await prisma.systemMetrics.findUnique({
      where: { date: today }
    });

    // Get overall statistics
    const [
      totalLeads,
      hotLeads,
      warmLeads,
      coldLeads,
      totalConversations,
      activeConversations,
      todayLeads,
      todayMessages
    ] = await Promise.all([
      prisma.lead.count(),
      prisma.lead.count({ where: { leadScore: 'HOT' } }),
      prisma.lead.count({ where: { leadScore: 'WARM' } }),
      prisma.lead.count({ where: { leadScore: 'COLD' } }),
      prisma.conversation.count(),
      prisma.conversation.count({ where: { status: 'ACTIVE' } }),
      prisma.lead.count({
        where: {
          createdAt: { gte: today }
        }
      }),
      prisma.message.count({
        where: {
          timestamp: { gte: today }
        }
      })
    ]);

    // Get recent activity
    const recentLeads = await prisma.lead.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        conversations: {
          take: 1,
          orderBy: { lastMessageAt: 'desc' },
          include: {
            messages: {
              take: 1,
              orderBy: { timestamp: 'desc' }
            }
          }
        }
      }
    });

    // Get metrics over last 7 days
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const weeklyMetrics = await prisma.systemMetrics.findMany({
      where: {
        date: { gte: sevenDaysAgo }
      },
      orderBy: { date: 'asc' }
    });

    res.json({
      today: {
        messagesReceived: todayMetrics?.messagesReceived || 0,
        messagesSent: todayMetrics?.messagesSent || 0,
        leadsCreated: todayLeads,
        totalMessages: todayMessages
      },
      overall: {
        totalLeads,
        hotLeads,
        warmLeads,
        coldLeads,
        totalConversations,
        activeConversations
      },
      recentActivity: recentLeads,
      weeklyTrend: weeklyMetrics
    });

  } catch (error) {
    logger.error('Error fetching dashboard metrics:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get conversation analytics
 */
async function getConversationAnalytics(req, res) {
  try {
    const { days = 7 } = req.query;
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));
    startDate.setHours(0, 0, 0, 0);

    // Messages by day
    const messagesByDay = await prisma.$queryRaw`
      SELECT 
        DATE(timestamp) as date,
        COUNT(*) as count,
        sender_type as "senderType"
      FROM messages
      WHERE timestamp >= ${startDate}
      GROUP BY DATE(timestamp), sender_type
      ORDER BY date ASC
    `;

    // Average response time
    const avgResponseTime = await prisma.$queryRaw`
      SELECT 
        AVG(EXTRACT(EPOCH FROM (
          SELECT MIN(m2.timestamp) 
          FROM messages m2 
          WHERE m2.conversation_id = m1.conversation_id 
          AND m2.sender_type = 'AI' 
          AND m2.timestamp > m1.timestamp
        ) - m1.timestamp)) as "avgResponseSeconds"
      FROM messages m1
      WHERE m1.sender_type = 'CUSTOMER'
      AND m1.timestamp >= ${startDate}
    `;

    // Messages per conversation
    const messagesPerConversation = await prisma.$queryRaw`
      SELECT 
        AVG(message_count) as "avgMessagesPerConversation"
      FROM (
        SELECT 
          conversation_id,
          COUNT(*) as message_count
        FROM messages
        WHERE timestamp >= ${startDate}
        GROUP BY conversation_id
      ) as conversation_stats
    `;

    res.json({
      messagesByDay,
      avgResponseTime: avgResponseTime[0]?.avgResponseSeconds || 0,
      avgMessagesPerConversation: messagesPerConversation[0]?.avgMessagesPerConversation || 0
    });

  } catch (error) {
    logger.error('Error fetching conversation analytics:', error);
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  getDashboardMetrics,
  getConversationAnalytics
};
