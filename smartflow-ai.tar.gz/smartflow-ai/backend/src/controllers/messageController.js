const { prisma } = require('../services/database/prismaClient');
const { generateConversationReply, scoreLead, getAISettings } = require('../services/ai/aiService');
const { sendWhatsAppMessage } = require('../services/whatsapp/whatsappService');
const { logger } = require('../utils/logger');
const { updateDashboardMetrics } = require('../utils/metricsHelper');

/**
 * CORE AUTOMATION PIPELINE
 * This function handles the complete flow when a WhatsApp message arrives
 */
async function handleIncomingMessage(message, whatsappClient) {
  try {
    logger.info(`🔄 Starting automation pipeline for ${message.from}`);

    // Extract phone number (remove @c.us suffix)
    const phoneNumber = message.from.replace('@c.us', '');
    const messageText = message.body;

    // Step 1: Get default business
    const business = await prisma.business.findFirst();
    if (!business) {
      logger.error('No business found in database');
      return;
    }

    // Step 2: Check if lead exists or create new one
    let lead = await prisma.lead.findUnique({
      where: { phoneNumber: phoneNumber }
    });

    if (!lead) {
      logger.info(`📝 Creating new lead for ${phoneNumber}`);
      lead = await prisma.lead.create({
        data: {
          phoneNumber: phoneNumber,
          businessId: business.id,
          leadScore: 'COLD',
          leadStatus: 'NEW'
        }
      });

      // Update metrics - new lead created
      await updateDashboardMetrics('leadsCreated');
      await updateDashboardMetrics('coldLeads');
    }

    // Step 3: Find or create conversation
    let conversation = await prisma.conversation.findFirst({
      where: {
        leadId: lead.id,
        status: 'ACTIVE'
      },
      include: {
        messages: {
          orderBy: { timestamp: 'asc' },
          take: 20 // Last 20 messages for context
        }
      }
    });

    if (!conversation) {
      logger.info(`💬 Creating new conversation for lead ${lead.id}`);
      conversation = await prisma.conversation.create({
        data: {
          leadId: lead.id,
          businessId: business.id,
          status: 'ACTIVE'
        },
        include: {
          messages: true
        }
      });
    }

    // Step 4: Store incoming message
    const incomingMessage = await prisma.message.create({
      data: {
        conversationId: conversation.id,
        senderType: 'CUSTOMER',
        messageText: messageText,
        messageType: 'text'
      }
    });

    logger.info(`💾 Stored incoming message: ${incomingMessage.id}`);

    // Update conversation last message time
    await prisma.conversation.update({
      where: { id: conversation.id },
      data: { lastMessageAt: new Date() }
    });

    // Update metrics - message received
    await updateDashboardMetrics('messagesReceived');

    // Step 5: Get AI settings
    const aiSettings = await getAISettings(business.id);
    if (!aiSettings) {
      logger.error('No AI settings found');
      return;
    }

    // Step 6: Generate AI reply
    logger.info('🤖 Generating AI reply...');
    
    // Prepare conversation history for AI
    const conversationHistory = [
      ...conversation.messages,
      incomingMessage
    ].map(msg => ({
      senderType: msg.senderType,
      messageText: msg.messageText
    }));

    const aiReply = await generateConversationReply(
      conversationHistory,
      lead,
      aiSettings
    );

    logger.info(`💡 AI generated reply: ${aiReply}`);

    // Step 7: Send WhatsApp reply
    await sendWhatsAppMessage(phoneNumber, aiReply);
    logger.info(`📤 Reply sent to ${phoneNumber}`);

    // Step 8: Store AI message
    await prisma.message.create({
      data: {
        conversationId: conversation.id,
        senderType: 'AI',
        messageText: aiReply,
        messageType: 'text'
      }
    });

    // Update metrics - message sent
    await updateDashboardMetrics('messagesSent');

    // Step 9: Run lead scoring (async, don't wait)
    scoreLeadAsync(lead.id, conversationHistory, lead, aiSettings);

    logger.info(`✅ Automation pipeline completed for ${phoneNumber}`);

  } catch (error) {
    logger.error('Error in automation pipeline:', error);
    
    // Send fallback message on error
    try {
      const phoneNumber = message.from.replace('@c.us', '');
      await sendWhatsAppMessage(
        phoneNumber,
        "Thank you for your message. We're experiencing technical difficulties. A team member will contact you shortly."
      );
    } catch (fallbackError) {
      logger.error('Error sending fallback message:', fallbackError);
    }
  }
}

/**
 * Async lead scoring - runs in background
 */
async function scoreLeadAsync(leadId, conversationHistory, leadInfo, aiSettings) {
  try {
    logger.info(`🎯 Scoring lead ${leadId}...`);
    
    const newScore = await scoreLead(conversationHistory, leadInfo, aiSettings);
    const oldScore = leadInfo.leadScore;

    if (newScore !== oldScore) {
      await prisma.lead.update({
        where: { id: leadId },
        data: { leadScore: newScore }
      });

      logger.info(`📊 Lead score updated: ${oldScore} → ${newScore}`);

      // Update metrics
      if (oldScore === 'COLD') await updateDashboardMetrics('coldLeads', -1);
      if (oldScore === 'WARM') await updateDashboardMetrics('warmLeads', -1);
      if (oldScore === 'HOT') await updateDashboardMetrics('hotLeads', -1);

      if (newScore === 'COLD') await updateDashboardMetrics('coldLeads');
      if (newScore === 'WARM') await updateDashboardMetrics('warmLeads');
      if (newScore === 'HOT') await updateDashboardMetrics('hotLeads');
    }
  } catch (error) {
    logger.error('Error in async lead scoring:', error);
  }
}

/**
 * Send a manual message (API endpoint)
 */
async function sendMessage(req, res) {
  try {
    const { phoneNumber, message } = req.body;

    if (!phoneNumber || !message) {
      return res.status(400).json({ error: 'Phone number and message are required' });
    }

    // Find or create lead
    let lead = await prisma.lead.findUnique({
      where: { phoneNumber: phoneNumber }
    });

    const business = await prisma.business.findFirst();

    if (!lead) {
      lead = await prisma.lead.create({
        data: {
          phoneNumber: phoneNumber,
          businessId: business.id,
          leadScore: 'COLD',
          leadStatus: 'NEW'
        }
      });
    }

    // Find or create conversation
    let conversation = await prisma.conversation.findFirst({
      where: {
        leadId: lead.id,
        status: 'ACTIVE'
      }
    });

    if (!conversation) {
      conversation = await prisma.conversation.create({
        data: {
          leadId: lead.id,
          businessId: business.id,
          status: 'ACTIVE'
        }
      });
    }

    // Send message
    await sendWhatsAppMessage(phoneNumber, message);

    // Store message
    await prisma.message.create({
      data: {
        conversationId: conversation.id,
        senderType: 'AGENT',
        messageText: message,
        messageType: 'text'
      }
    });

    await updateDashboardMetrics('messagesSent');

    res.json({ success: true, message: 'Message sent successfully' });

  } catch (error) {
    logger.error('Error sending message:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get messages for a conversation
 */
async function getMessages(req, res) {
  try {
    const { conversationId } = req.params;

    const messages = await prisma.message.findMany({
      where: { conversationId: conversationId },
      orderBy: { timestamp: 'asc' }
    });

    res.json(messages);

  } catch (error) {
    logger.error('Error fetching messages:', error);
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  handleIncomingMessage,
  sendMessage,
  getMessages
};
