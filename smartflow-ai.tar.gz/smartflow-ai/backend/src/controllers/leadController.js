const { prisma } = require('../services/database/prismaClient');
const { logger } = require('../utils/logger');

/**
 * Get all leads with pagination and filters
 */
async function getLeads(req, res) {
  try {
    const { 
      page = 1, 
      limit = 20, 
      score, 
      status,
      search 
    } = req.query;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const take = parseInt(limit);

    // Build filter conditions
    const where = {};
    
    if (score) {
      where.leadScore = score;
    }
    
    if (status) {
      where.leadStatus = status;
    }
    
    if (search) {
      where.OR = [
        { phoneNumber: { contains: search } },
        { name: { contains: search, mode: 'insensitive' } }
      ];
    }

    const [leads, total] = await Promise.all([
      prisma.lead.findMany({
        where,
        include: {
          business: {
            select: { name: true, industry: true }
          },
          conversations: {
            select: {
              id: true,
              lastMessageAt: true,
              status: true
            },
            orderBy: { lastMessageAt: 'desc' },
            take: 1
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take
      }),
      prisma.lead.count({ where })
    ]);

    res.json({
      leads,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit))
      }
    });

  } catch (error) {
    logger.error('Error fetching leads:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get single lead by ID
 */
async function getLeadById(req, res) {
  try {
    const { id } = req.params;

    const lead = await prisma.lead.findUnique({
      where: { id },
      include: {
        business: true,
        conversations: {
          include: {
            messages: {
              orderBy: { timestamp: 'desc' },
              take: 50
            }
          },
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!lead) {
      return res.status(404).json({ error: 'Lead not found' });
    }

    res.json(lead);

  } catch (error) {
    logger.error('Error fetching lead:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Update lead information
 */
async function updateLead(req, res) {
  try {
    const { id } = req.params;
    const { name, leadScore, leadStatus, notes } = req.body;

    const updateData = {};
    if (name !== undefined) updateData.name = name;
    if (leadScore !== undefined) updateData.leadScore = leadScore;
    if (leadStatus !== undefined) updateData.leadStatus = leadStatus;
    if (notes !== undefined) updateData.notes = notes;

    const lead = await prisma.lead.update({
      where: { id },
      data: updateData
    });

    res.json(lead);

  } catch (error) {
    logger.error('Error updating lead:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get lead statistics
 */
async function getLeadStats(req, res) {
  try {
    const [total, hot, warm, cold, spam, newLeads] = await Promise.all([
      prisma.lead.count(),
      prisma.lead.count({ where: { leadScore: 'HOT' } }),
      prisma.lead.count({ where: { leadScore: 'WARM' } }),
      prisma.lead.count({ where: { leadScore: 'COLD' } }),
      prisma.lead.count({ where: { leadScore: 'SPAM' } }),
      prisma.lead.count({ where: { leadStatus: 'NEW' } })
    ]);

    res.json({
      total,
      byScore: {
        hot,
        warm,
        cold,
        spam
      },
      byStatus: {
        new: newLeads
      }
    });

  } catch (error) {
    logger.error('Error fetching lead stats:', error);
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  getLeads,
  getLeadById,
  updateLead,
  getLeadStats
};
