const { prisma } = require('../services/database/prismaClient');
const { logger } = require('../utils/logger');

/**
 * Get all conversations with pagination
 */
async function getConversations(req, res) {
  try {
    const { 
      page = 1, 
      limit = 20,
      status,
      leadId 
    } = req.query;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const take = parseInt(limit);

    const where = {};
    
    if (status) {
      where.status = status;
    }
    
    if (leadId) {
      where.leadId = leadId;
    }

    const [conversations, total] = await Promise.all([
      prisma.conversation.findMany({
        where,
        include: {
          lead: {
            select: {
              id: true,
              phoneNumber: true,
              name: true,
              leadScore: true,
              leadStatus: true
            }
          },
          messages: {
            orderBy: { timestamp: 'desc' },
            take: 1
          },
          _count: {
            select: { messages: true }
          }
        },
        orderBy: { lastMessageAt: 'desc' },
        skip,
        take
      }),
      prisma.conversation.count({ where })
    ]);

    res.json({
      conversations,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / parseInt(limit))
      }
    });

  } catch (error) {
    logger.error('Error fetching conversations:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Get single conversation with all messages
 */
async function getConversationById(req, res) {
  try {
    const { id } = req.params;

    const conversation = await prisma.conversation.findUnique({
      where: { id },
      include: {
        lead: {
          include: {
            business: true
          }
        },
        messages: {
          orderBy: { timestamp: 'asc' }
        }
      }
    });

    if (!conversation) {
      return res.status(404).json({ error: 'Conversation not found' });
    }

    res.json(conversation);

  } catch (error) {
    logger.error('Error fetching conversation:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Update conversation status
 */
async function updateConversation(req, res) {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['ACTIVE', 'CLOSED'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status. Must be ACTIVE or CLOSED' });
    }

    const conversation = await prisma.conversation.update({
      where: { id },
      data: { status }
    });

    res.json(conversation);

  } catch (error) {
    logger.error('Error updating conversation:', error);
    res.status(500).json({ error: error.message });
  }
}

module.exports = {
  getConversations,
  getConversationById,
  updateConversation
};
