const { prisma } = require('../services/database/prismaClient');
const { logger } = require('../utils/logger');

/**
 * Get AI settings for a business
 */
async function getAISettings(req, res) {
  try {
    const { businessId } = req.query;

    let settings;
    
    if (businessId) {
      settings = await prisma.aISettings.findFirst({
        where: {
          businessId: businessId,
          isActive: true
        },
        include: {
          business: {
            select: {
              id: true,
              name: true,
              industry: true
            }
          }
        }
      });
    } else {
      // Get default business settings
      const defaultBusiness = await prisma.business.findFirst();
      if (defaultBusiness) {
        settings = await prisma.aISettings.findFirst({
          where: {
            businessId: defaultBusiness.id,
            isActive: true
          },
          include: {
            business: {
              select: {
                id: true,
                name: true,
                industry: true
              }
            }
          }
        });
      }
    }

    if (!settings) {
      return res.status(404).json({ error: 'AI settings not found' });
    }

    // Don't expose API keys in response
    const safeSettings = {
      ...settings,
      apiKey: settings.apiKey ? '***REDACTED***' : null
    };

    res.json(safeSettings);

  } catch (error) {
    logger.error('Error fetching AI settings:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Update AI settings
 */
async function updateAISettings(req, res) {
  try {
    const { id } = req.params;
    const {
      provider,
      apiKey,
      model,
      temperature,
      maxTokens,
      systemPrompt
    } = req.body;

    const updateData = {};
    
    if (provider !== undefined) updateData.provider = provider;
    if (apiKey !== undefined) updateData.apiKey = apiKey;
    if (model !== undefined) updateData.model = model;
    if (temperature !== undefined) updateData.temperature = parseFloat(temperature);
    if (maxTokens !== undefined) updateData.maxTokens = parseInt(maxTokens);
    if (systemPrompt !== undefined) updateData.systemPrompt = systemPrompt;

    const settings = await prisma.aISettings.update({
      where: { id },
      data: updateData
    });

    // Don't expose API key in response
    const safeSettings = {
      ...settings,
      apiKey: settings.apiKey ? '***REDACTED***' : null
    };

    res.json(safeSettings);

  } catch (error) {
    logger.error('Error updating AI settings:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Create AI settings for a business
 */
async function createAISettings(req, res) {
  try {
    const {
      businessId,
      provider = 'openai',
      apiKey,
      model = 'gpt-3.5-turbo',
      temperature = 0.7,
      maxTokens = 500,
      systemPrompt
    } = req.body;

    if (!businessId) {
      return res.status(400).json({ error: 'businessId is required' });
    }

    const settings = await prisma.aISettings.create({
      data: {
        businessId,
        provider,
        apiKey,
        model,
        temperature: parseFloat(temperature),
        maxTokens: parseInt(maxTokens),
        systemPrompt: systemPrompt || 'You are a helpful business assistant. Be friendly, concise, and professional.',
        isActive: true
      }
    });

    // Don't expose API key in response
    const safeSettings = {
      ...settings,
      apiKey: settings.apiKey ? '***REDACTED***' : null
    };

    res.json(safeSettings);

  } catch (error) {
    logger.error('Error creating AI settings:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * Test AI configuration
 */
async function testAIConfig(req, res) {
  try {
    const { provider, model, apiKey, testMessage = 'Hello, how are you?' } = req.body;

    if (!provider || !apiKey) {
      return res.status(400).json({ error: 'provider and apiKey are required' });
    }

    // Import AI service dynamically to test
    const { generateConversationReply } = require('../services/ai/aiService');

    const testSettings = {
      provider,
      model: model || 'gpt-3.5-turbo',
      temperature: 0.7,
      maxTokens: 100,
      systemPrompt: 'You are a helpful assistant. Respond briefly.'
    };

    const conversationHistory = [
      { senderType: 'CUSTOMER', messageText: testMessage }
    ];

    const leadInfo = {
      phoneNumber: 'test',
      name: 'Test User',
      leadScore: 'COLD'
    };

    // Temporarily set API key for test
    const originalKey = process.env[`${provider.toUpperCase()}_API_KEY`];
    process.env[`${provider.toUpperCase()}_API_KEY`] = apiKey;

    const reply = await generateConversationReply(
      conversationHistory,
      leadInfo,
      testSettings
    );

    // Restore original key
    if (originalKey) {
      process.env[`${provider.toUpperCase()}_API_KEY`] = originalKey;
    }

    res.json({
      success: true,
      testMessage,
      aiResponse: reply,
      provider,
      model
    });

  } catch (error) {
    logger.error('Error testing AI config:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
}

module.exports = {
  getAISettings,
  updateAISettings,
  createAISettings,
  testAIConfig
};
