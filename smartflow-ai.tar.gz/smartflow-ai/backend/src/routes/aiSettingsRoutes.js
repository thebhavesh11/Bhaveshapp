const express = require('express');
const router = express.Router();
const aiSettingsController = require('../controllers/aiSettingsController');

// GET /api/ai-settings - Get AI settings
router.get('/', aiSettingsController.getAISettings);

// POST /api/ai-settings - Create AI settings
router.post('/', aiSettingsController.createAISettings);

// PUT /api/ai-settings/:id - Update AI settings
router.put('/:id', aiSettingsController.updateAISettings);

// POST /api/ai-settings/test - Test AI configuration
router.post('/test', aiSettingsController.testAIConfig);

module.exports = router;
