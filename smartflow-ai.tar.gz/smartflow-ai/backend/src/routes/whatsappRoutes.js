const express = require('express');
const router = express.Router();
const whatsappController = require('../controllers/whatsappController');

// GET /api/whatsapp/status - Get connection status
router.get('/status', whatsappController.getStatus);

// GET /api/whatsapp/qr - Get QR code
router.get('/qr', whatsappController.getQRCode);

// GET /api/whatsapp/session - Get session info
router.get('/session', whatsappController.getSessionInfo);

module.exports = router;
