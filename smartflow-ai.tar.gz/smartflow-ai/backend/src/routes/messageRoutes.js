const express = require('express');
const router = express.Router();
const messageController = require('../controllers/messageController');

// POST /api/messages/send - Send a manual message
router.post('/send', messageController.sendMessage);

// GET /api/messages/:conversationId - Get messages for a conversation
router.get('/:conversationId', messageController.getMessages);

module.exports = router;
