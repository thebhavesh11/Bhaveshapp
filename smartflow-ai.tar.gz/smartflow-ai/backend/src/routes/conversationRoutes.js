const express = require('express');
const router = express.Router();
const conversationController = require('../controllers/conversationController');

// GET /api/conversations - Get all conversations
router.get('/', conversationController.getConversations);

// GET /api/conversations/:id - Get single conversation
router.get('/:id', conversationController.getConversationById);

// PUT /api/conversations/:id - Update conversation
router.put('/:id', conversationController.updateConversation);

module.exports = router;
