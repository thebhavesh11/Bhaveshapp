const express = require('express');
const router = express.Router();
const leadController = require('../controllers/leadController');

// GET /api/leads - Get all leads with filters
router.get('/', leadController.getLeads);

// GET /api/leads/stats - Get lead statistics
router.get('/stats', leadController.getLeadStats);

// GET /api/leads/:id - Get single lead
router.get('/:id', leadController.getLeadById);

// PUT /api/leads/:id - Update lead
router.put('/:id', leadController.updateLead);

module.exports = router;
