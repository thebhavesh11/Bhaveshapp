const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');

// GET /api/dashboard/metrics - Get dashboard metrics
router.get('/metrics', dashboardController.getDashboardMetrics);

// GET /api/dashboard/analytics - Get conversation analytics
router.get('/analytics', dashboardController.getConversationAnalytics);

module.exports = router;
