const { prisma } = require('../services/database/prismaClient');
const { logger } = require('./logger');

/**
 * Update dashboard metrics
 * @param {string} metric - Metric to update (messagesReceived, messagesSent, leadsCreated, hotLeads, warmLeads, coldLeads)
 * @param {number} increment - Amount to increment (default 1, can be negative)
 */
async function updateDashboardMetrics(metric, increment = 1) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Check if today's metrics exist
    let metrics = await prisma.systemMetrics.findUnique({
      where: { date: today }
    });

    if (!metrics) {
      // Create today's metrics
      metrics = await prisma.systemMetrics.create({
        data: {
          date: today,
          messagesReceived: 0,
          messagesSent: 0,
          leadsCreated: 0,
          hotLeads: 0,
          warmLeads: 0,
          coldLeads: 0
        }
      });
    }

    // Update the specific metric
    const updateData = {};
    
    switch (metric) {
      case 'messagesReceived':
        updateData.messagesReceived = metrics.messagesReceived + increment;
        break;
      case 'messagesSent':
        updateData.messagesSent = metrics.messagesSent + increment;
        break;
      case 'leadsCreated':
        updateData.leadsCreated = metrics.leadsCreated + increment;
        break;
      case 'hotLeads':
        updateData.hotLeads = metrics.hotLeads + increment;
        break;
      case 'warmLeads':
        updateData.warmLeads = metrics.warmLeads + increment;
        break;
      case 'coldLeads':
        updateData.coldLeads = metrics.coldLeads + increment;
        break;
      default:
        logger.warn(`Unknown metric: ${metric}`);
        return;
    }

    await prisma.systemMetrics.update({
      where: { date: today },
      data: updateData
    });

  } catch (error) {
    logger.error('Error updating dashboard metrics:', error);
  }
}

/**
 * Get metrics for a date range
 */
async function getMetricsForDateRange(startDate, endDate) {
  try {
    const metrics = await prisma.systemMetrics.findMany({
      where: {
        date: {
          gte: startDate,
          lte: endDate
        }
      },
      orderBy: { date: 'asc' }
    });

    return metrics;
  } catch (error) {
    logger.error('Error fetching metrics for date range:', error);
    return [];
  }
}

module.exports = {
  updateDashboardMetrics,
  getMetricsForDateRange
};
