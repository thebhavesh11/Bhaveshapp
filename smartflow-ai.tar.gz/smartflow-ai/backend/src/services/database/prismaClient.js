const { PrismaClient } = require('@prisma/client');
const { logger } = require('../../utils/logger');

const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' 
    ? ['query', 'info', 'warn', 'error'] 
    : ['error'],
});

async function initializeDatabase() {
  try {
    await prisma.$connect();
    logger.info('Database connected successfully');

    // Create default business if it doesn't exist
    const businessCount = await prisma.business.count();
    if (businessCount === 0) {
      const defaultBusiness = await prisma.business.create({
        data: {
          name: process.env.DEFAULT_BUSINESS_NAME || 'SmartFlow AI Demo',
          industry: process.env.DEFAULT_BUSINESS_INDUSTRY || 'Technology',
          description: 'Default business for SmartFlow AI platform'
        }
      });

      // Create default AI settings
      await prisma.aISettings.create({
        data: {
          businessId: defaultBusiness.id,
          provider: process.env.DEFAULT_AI_PROVIDER || 'openai',
          model: process.env.DEFAULT_AI_MODEL || 'gpt-3.5-turbo',
          temperature: parseFloat(process.env.DEFAULT_AI_TEMPERATURE) || 0.7,
          maxTokens: parseInt(process.env.DEFAULT_AI_MAX_TOKENS) || 500,
          systemPrompt: 'You are a helpful business assistant for SmartFlow AI. Be friendly, concise, and professional. Your responses should be suitable for WhatsApp - keep them short (2-3 sentences max). Guide conversations naturally toward scheduling appointments or answering product inquiries. Ask relevant follow-up questions to qualify leads.',
          isActive: true
        }
      });

      logger.info('Default business and AI settings created');
    }

    // Initialize WhatsApp session record
    const sessionCount = await prisma.whatsAppSession.count();
    if (sessionCount === 0) {
      await prisma.whatsAppSession.create({
        data: {
          sessionId: 'default',
          isConnected: false
        }
      });
      logger.info('WhatsApp session record initialized');
    }

    return prisma;
  } catch (error) {
    logger.error('Database initialization error:', error);
    throw error;
  }
}

async function disconnectDatabase() {
  try {
    await prisma.$disconnect();
    logger.info('Database disconnected');
  } catch (error) {
    logger.error('Error disconnecting database:', error);
  }
}

module.exports = {
  prisma,
  initializeDatabase,
  disconnectDatabase
};
