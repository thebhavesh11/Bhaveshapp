const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const qrcodeTerminal = require('qrcode-terminal');
const path = require('path');
const { logger } = require('../../utils/logger');
const { prisma } = require('../database/prismaClient');
const { handleIncomingMessage } = require('../../controllers/messageController');

let client = null;
let qrCodeData = null;
let isInitializing = false;
let isReady = false;

// Session path for persistence
const SESSION_PATH = process.env.WHATSAPP_SESSION_PATH || path.join(__dirname, '../../../whatsapp-session');

async function initializeWhatsApp() {
  if (isInitializing) {
    logger.info('WhatsApp client is already initializing...');
    return;
  }

  if (client) {
    logger.info('WhatsApp client already exists');
    return client;
  }

  try {
    isInitializing = true;
    logger.info('Initializing WhatsApp client with LocalAuth...');
    logger.info(`Session path: ${SESSION_PATH}`);

    client = new Client({
      authStrategy: new LocalAuth({
        clientId: 'smartflow-ai-session',
        dataPath: SESSION_PATH
      }),
      puppeteer: {
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--single-process',
          '--disable-gpu'
        ]
      }
    });

    // QR Code event
    client.on('qr', async (qr) => {
      logger.info('QR Code received, generating image...');
      qrCodeData = qr;
      
      // Display QR in terminal for local development
      qrcodeTerminal.generate(qr, { small: true });
      
      // Generate QR code image
      try {
        const qrImage = await qrcode.toDataURL(qr);
        
        // Update database with QR code
        await prisma.whatsAppSession.updateMany({
          where: { sessionId: 'default' },
          data: {
            qrCode: qrImage,
            isConnected: false
          }
        });
        
        logger.info('QR Code saved to database');
      } catch (error) {
        logger.error('Error generating QR code image:', error);
      }
    });

    // Ready event
    client.on('ready', async () => {
      isReady = true;
      logger.info('✅ WhatsApp client is ready!');
      
      const info = client.info;
      logger.info(`Connected as: ${info.pushname} (${info.wid.user})`);
      
      // Update database
      await prisma.whatsAppSession.updateMany({
        where: { sessionId: 'default' },
        data: {
          isConnected: true,
          phoneNumber: info.wid.user,
          qrCode: null,
          lastConnected: new Date()
        }
      });
      
      qrCodeData = null;
    });

    // Authenticated event
    client.on('authenticated', () => {
      logger.info('WhatsApp authenticated successfully');
    });

    // Authentication failure event
    client.on('auth_failure', async (msg) => {
      logger.error('WhatsApp authentication failure:', msg);
      await prisma.whatsAppSession.updateMany({
        where: { sessionId: 'default' },
        data: { isConnected: false }
      });
    });

    // Disconnected event
    client.on('disconnected', async (reason) => {
      logger.warn('WhatsApp client disconnected:', reason);
      isReady = false;
      
      await prisma.whatsAppSession.updateMany({
        where: { sessionId: 'default' },
        data: { isConnected: false }
      });
      
      // Attempt to reconnect
      logger.info('Attempting to reconnect...');
      setTimeout(() => {
        initializeWhatsApp();
      }, 5000);
    });

    // Message event - THIS IS THE CORE AUTOMATION TRIGGER
    client.on('message', async (message) => {
      try {
        logger.info(`📨 Incoming message from ${message.from}: ${message.body}`);
        
        // Ignore group messages and messages from self
        if (message.from.includes('@g.us') || message.fromMe) {
          return;
        }
        
        // Process the message through automation pipeline
        await handleIncomingMessage(message, client);
        
      } catch (error) {
        logger.error('Error handling incoming message:', error);
      }
    });

    // Message creation event (for sent messages)
    client.on('message_create', async (message) => {
      // This fires for all messages including ones we send
      if (message.fromMe) {
        logger.info(`📤 Outgoing message to ${message.to}: ${message.body}`);
      }
    });

    // Initialize the client
    await client.initialize();
    logger.info('WhatsApp client initialization started...');
    
    isInitializing = false;
    return client;
    
  } catch (error) {
    logger.error('Error initializing WhatsApp client:', error);
    isInitializing = false;
    throw error;
  }
}

async function getWhatsAppStatus() {
  try {
    const session = await prisma.whatsAppSession.findFirst({
      where: { sessionId: 'default' }
    });

    return {
      isConnected: isReady && client !== null,
      hasQR: qrCodeData !== null,
      qrCode: session?.qrCode || qrCodeData,
      phoneNumber: session?.phoneNumber,
      lastConnected: session?.lastConnected,
      clientState: client ? client.info : null
    };
  } catch (error) {
    logger.error('Error getting WhatsApp status:', error);
    return {
      isConnected: false,
      hasQR: false,
      error: error.message
    };
  }
}

async function sendWhatsAppMessage(phoneNumber, message) {
  try {
    if (!client || !isReady) {
      throw new Error('WhatsApp client is not ready');
    }

    // Format phone number (remove special characters, ensure country code)
    const formattedNumber = phoneNumber.replace(/\D/g, '');
    const chatId = `${formattedNumber}@c.us`;

    await client.sendMessage(chatId, message);
    logger.info(`✅ Message sent to ${phoneNumber}`);
    
    return { success: true };
  } catch (error) {
    logger.error(`Error sending WhatsApp message to ${phoneNumber}:`, error);
    throw error;
  }
}

function getWhatsAppClient() {
  return client;
}

function getCurrentQR() {
  return qrCodeData;
}

module.exports = {
  initializeWhatsApp,
  getWhatsAppStatus,
  sendWhatsAppMessage,
  getWhatsAppClient,
  getCurrentQR
};
