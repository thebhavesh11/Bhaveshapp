const OpenAI = require('openai');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const axios = require('axios');
const { logger } = require('../../utils/logger');
const { prisma } = require('../database/prismaClient');

// Initialize AI clients
let openaiClient = null;
let geminiClient = null;

function initializeOpenAI() {
  if (!openaiClient && process.env.OPENAI_API_KEY) {
    openaiClient = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });
    logger.info('OpenAI client initialized');
  }
  return openaiClient;
}

function initializeGemini() {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    logger.info('Gemini client initialized');
  }
  return geminiClient;
}

/**
 * Generate a conversation reply using the configured AI provider
 */
async function generateConversationReply(conversationHistory, leadInfo, aiSettings) {
  try {
    const provider = aiSettings?.provider || 'openai';
    const model = aiSettings?.model || 'gpt-3.5-turbo';
    const temperature = aiSettings?.temperature || 0.7;
    const maxTokens = aiSettings?.maxTokens || 500;
    const systemPrompt = aiSettings?.systemPrompt || getDefaultSystemPrompt();

    logger.info(`Generating reply using ${provider} (${model})`);

    // Build conversation context
    const messages = [
      {
        role: 'system',
        content: `${systemPrompt}\n\nLead Information:\n- Phone: ${leadInfo.phoneNumber}\n- Name: ${leadInfo.name || 'Unknown'}\n- Current Status: ${leadInfo.leadScore}`
      },
      ...conversationHistory.map(msg => ({
        role: msg.senderType === 'CUSTOMER' ? 'user' : 'assistant',
        content: msg.messageText
      }))
    ];

    let reply = '';

    switch (provider) {
      case 'openai':
        reply = await generateOpenAIReply(messages, model, temperature, maxTokens);
        break;
      
      case 'gemini':
        reply = await generateGeminiReply(messages, model, temperature, maxTokens);
        break;
      
      case 'openrouter':
        reply = await generateOpenRouterReply(messages, model, temperature, maxTokens);
        break;
      
      default:
        throw new Error(`Unsupported AI provider: ${provider}`);
    }

    return reply;

  } catch (error) {
    logger.error('Error generating conversation reply:', error);
    
    // Fallback response
    return "Thanks for your message! I'm currently experiencing technical difficulties. A team member will get back to you shortly.";
  }
}

/**
 * Generate reply using OpenAI
 */
async function generateOpenAIReply(messages, model, temperature, maxTokens) {
  try {
    const client = initializeOpenAI();
    if (!client) {
      throw new Error('OpenAI client not initialized');
    }

    const response = await client.chat.completions.create({
      model: model,
      messages: messages,
      temperature: temperature,
      max_tokens: maxTokens,
      presence_penalty: 0.6,
      frequency_penalty: 0.5
    });

    return response.choices[0].message.content.trim();
  } catch (error) {
    logger.error('OpenAI API error:', error);
    throw error;
  }
}

/**
 * Generate reply using Google Gemini
 */
async function generateGeminiReply(messages, model, temperature, maxTokens) {
  try {
    const client = initializeGemini();
    if (!client) {
      throw new Error('Gemini client not initialized');
    }

    const genModel = client.getGenerativeModel({ model: model || 'gemini-pro' });

    // Convert messages to Gemini format
    const systemMessage = messages.find(m => m.role === 'system');
    const conversationMessages = messages.filter(m => m.role !== 'system');
    
    const prompt = `${systemMessage?.content || ''}\n\nConversation:\n${
      conversationMessages.map(m => `${m.role === 'user' ? 'Customer' : 'Assistant'}: ${m.content}`).join('\n')
    }\n\nAssistant:`;

    const result = await genModel.generateContent({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: temperature,
        maxOutputTokens: maxTokens
      }
    });

    return result.response.text().trim();
  } catch (error) {
    logger.error('Gemini API error:', error);
    throw error;
  }
}

/**
 * Generate reply using OpenRouter
 */
async function generateOpenRouterReply(messages, model, temperature, maxTokens) {
  try {
    if (!process.env.OPENROUTER_API_KEY) {
      throw new Error('OpenRouter API key not configured');
    }

    const response = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: model || 'openai/gpt-3.5-turbo',
        messages: messages,
        temperature: temperature,
        max_tokens: maxTokens
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data.choices[0].message.content.trim();
  } catch (error) {
    logger.error('OpenRouter API error:', error);
    throw error;
  }
}

/**
 * Score a lead based on conversation analysis
 */
async function scoreLead(conversationHistory, leadInfo, aiSettings) {
  try {
    const provider = aiSettings?.provider || 'openai';
    const model = aiSettings?.model || 'gpt-3.5-turbo';

    logger.info(`Scoring lead ${leadInfo.phoneNumber} using ${provider}`);

    const scoringPrompt = `Analyze this customer conversation and classify the lead quality.

Conversation History:
${conversationHistory.map(msg => `${msg.senderType}: ${msg.messageText}`).join('\n')}

Based on the conversation, classify this lead as one of the following:
- HOT: Shows strong buying intent, asked about pricing/booking, ready to purchase
- WARM: Interested and engaged, asking relevant questions, potential customer
- COLD: Minimal engagement, vague responses, low interest
- SPAM: Irrelevant messages, promotional content, or spam

Respond with ONLY one word: HOT, WARM, COLD, or SPAM`;

    const messages = [
      { role: 'system', content: 'You are a lead qualification expert. Analyze conversations and classify lead quality.' },
      { role: 'user', content: scoringPrompt }
    ];

    let score = '';

    switch (provider) {
      case 'openai':
        score = await generateOpenAIReply(messages, model, 0.3, 10);
        break;
      
      case 'gemini':
        score = await generateGeminiReply(messages, model, 0.3, 10);
        break;
      
      case 'openrouter':
        score = await generateOpenRouterReply(messages, model, 0.3, 10);
        break;
      
      default:
        score = 'COLD';
    }

    // Validate and clean the score
    const validScores = ['HOT', 'WARM', 'COLD', 'SPAM'];
    const cleanScore = score.toUpperCase().trim();
    
    return validScores.includes(cleanScore) ? cleanScore : 'COLD';

  } catch (error) {
    logger.error('Error scoring lead:', error);
    return 'COLD'; // Default to COLD on error
  }
}

/**
 * Get default system prompt for conversation AI
 */
function getDefaultSystemPrompt() {
  return `You are a helpful, friendly business assistant communicating via WhatsApp. 

Guidelines:
- Keep responses SHORT (1-3 sentences maximum)
- Be conversational and friendly
- Ask ONE relevant follow-up question to keep the conversation going
- Guide toward scheduling, inquiries, or product information
- Be professional but warm
- Use casual language appropriate for messaging
- Do not use emojis unless the customer uses them first
- If asked about pricing or services, provide helpful information and offer to connect them with a specialist`;
}

/**
 * Get AI settings for a business
 */
async function getAISettings(businessId) {
  try {
    let settings = await prisma.aISettings.findFirst({
      where: {
        businessId: businessId,
        isActive: true
      }
    });

    if (!settings) {
      // Get default business if no businessId provided
      const defaultBusiness = await prisma.business.findFirst();
      if (defaultBusiness) {
        settings = await prisma.aISettings.findFirst({
          where: {
            businessId: defaultBusiness.id,
            isActive: true
          }
        });
      }
    }

    return settings;
  } catch (error) {
    logger.error('Error fetching AI settings:', error);
    return null;
  }
}

module.exports = {
  generateConversationReply,
  scoreLead,
  getAISettings,
  initializeOpenAI,
  initializeGemini
};
