#!/bin/sh

# Start script for SmartFlow AI

echo "🚀 Starting SmartFlow AI Platform..."

# Run database migrations
echo "📊 Running database migrations..."
cd /app/backend
npx prisma migrate deploy

# Start backend in background
echo "🔧 Starting backend server..."
node src/server.js &

# Start frontend
echo "🎨 Starting frontend server..."
cd /app/frontend
npm start
