'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

export default function LeadScoreChart({ hot, warm, cold }) {
  const data = [
    { name: 'Hot Leads', value: hot, color: '#ef4444' },
    { name: 'Warm Leads', value: warm, color: '#f59e0b' },
    { name: 'Cold Leads', value: cold, color: '#3b82f6' },
  ];

  const total = hot + warm + cold;

  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Lead Distribution</h3>
      {total > 0 ? (
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      ) : (
        <div className="flex items-center justify-center h-64 text-gray-500">
          No leads yet
        </div>
      )}
    </div>
  );
}
