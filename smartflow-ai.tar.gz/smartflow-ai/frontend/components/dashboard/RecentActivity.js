import { formatDistanceToNow } from 'date-fns';
import { User, MessageCircle } from 'lucide-react';

export default function RecentActivity({ recentLeads }) {
  const getScoreColor = (score) => {
    switch (score) {
      case 'HOT': return 'bg-red-100 text-red-700';
      case 'WARM': return 'bg-yellow-100 text-yellow-700';
      case 'COLD': return 'bg-blue-100 text-blue-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
      <div className="space-y-4">
        {recentLeads && recentLeads.length > 0 ? (
          recentLeads.map((lead) => (
            <div key={lead.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                  <User size={20} className="text-primary-600" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">
                  {lead.name || lead.phoneNumber}
                </p>
                <p className="text-sm text-gray-500">
                  {lead.phoneNumber}
                </p>
                {lead.conversations && lead.conversations[0]?.messages?.[0] && (
                  <div className="mt-1 flex items-center text-xs text-gray-500">
                    <MessageCircle size={12} className="mr-1" />
                    <span className="truncate">
                      {lead.conversations[0].messages[0].messageText.substring(0, 50)}...
                    </span>
                  </div>
                )}
                <p className="text-xs text-gray-400 mt-1">
                  {formatDistanceToNow(new Date(lead.createdAt), { addSuffix: true })}
                </p>
              </div>
              <div>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getScoreColor(lead.leadScore)}`}>
                  {lead.leadScore}
                </span>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500 py-8">No recent activity</p>
        )}
      </div>
    </div>
  );
}
