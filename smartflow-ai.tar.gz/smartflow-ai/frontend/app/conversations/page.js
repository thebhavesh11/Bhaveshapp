'use client';

import { useEffect, useState } from 'react';
import axios from 'axios';
import { MessageSquare, User, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function ConversationsPage() {
  const [conversations, setConversations] = useState([]);
  const [selectedConv, setSelectedConv] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConversations();
  }, []);

  useEffect(() => {
    if (selectedConv) {
      fetchMessages(selectedConv.id);
    }
  }, [selectedConv]);

  const fetchConversations = async () => {
    try {
      const response = await axios.get('/api/conversations');
      setConversations(response.data.conversations);
      if (response.data.conversations.length > 0) {
        setSelectedConv(response.data.conversations[0]);
      }
    } catch (error) {
      console.error('Error fetching conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (conversationId) => {
    try {
      const response = await axios.get(`/api/conversations/${conversationId}`);
      setMessages(response.data.messages || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Conversations</h1>
        <p className="text-gray-600 mt-2">View all WhatsApp conversations</p>
      </div>

      {conversations.length > 0 ? (
        <div className="grid grid-cols-12 gap-6 h-[calc(100vh-12rem)]">
          {/* Conversations List */}
          <div className="col-span-4 card overflow-y-auto">
            <h3 className="text-lg font-semibold mb-4">All Conversations</h3>
            <div className="space-y-2">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => setSelectedConv(conv)}
                  className={`p-4 rounded-lg cursor-pointer transition-colors ${
                    selectedConv?.id === conv.id
                      ? 'bg-primary-50 border-primary-200 border-2'
                      : 'bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3 flex-1">
                      <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center flex-shrink-0">
                        <User size={20} className="text-primary-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 truncate">
                          {conv.lead?.name || conv.lead?.phoneNumber}
                        </p>
                        <p className="text-sm text-gray-500 truncate">
                          {conv.messages && conv.messages.length > 0 
                            ? conv.messages[0].messageText.substring(0, 40) + '...'
                            : 'No messages'}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      conv.status === 'ACTIVE' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {conv.status}
                    </span>
                    <span className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(conv.lastMessageAt), { addSuffix: true })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Messages View */}
          <div className="col-span-8 card flex flex-col">
            {selectedConv ? (
              <>
                <div className="border-b pb-4 mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center">
                      <User size={24} className="text-primary-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">
                        {selectedConv.lead?.name || 'Unknown'}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {selectedConv.lead?.phoneNumber}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 pr-4">
                  {messages.map((msg, index) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.senderType === 'CUSTOMER' ? 'justify-start' : 'justify-end'}`}
                    >
                      <div
                        className={`max-w-sm px-4 py-2 rounded-lg ${
                          msg.senderType === 'CUSTOMER'
                            ? 'bg-gray-100 text-gray-900'
                            : msg.senderType === 'AI'
                            ? 'bg-primary-600 text-white'
                            : 'bg-green-600 text-white'
                        }`}
                      >
                        <p className="text-sm">{msg.messageText}</p>
                        <p className={`text-xs mt-1 ${
                          msg.senderType === 'CUSTOMER' ? 'text-gray-500' : 'text-white/70'
                        }`}>
                          {new Date(msg.timestamp).toLocaleTimeString()} • {msg.senderType}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-500">
                Select a conversation to view messages
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="card text-center py-12">
          <MessageSquare className="mx-auto text-gray-400 mb-4" size={48} />
          <p className="text-gray-600">No conversations yet</p>
          <p className="text-sm text-gray-500 mt-2">
            Conversations will appear here when customers message you
          </p>
        </div>
      )}
    </div>
  );
}
