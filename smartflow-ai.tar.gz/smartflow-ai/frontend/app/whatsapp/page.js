'use client';

import { useEffect, useState } from 'react';
import axios from 'axios';
import { Phone, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import Image from 'next/image';

export default function WhatsAppPage() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 3000); // Poll every 3 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await axios.get('/api/whatsapp/qr');
      setStatus(response.data);
    } catch (error) {
      console.error('Error fetching WhatsApp status:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">WhatsApp Connection</h1>
        <p className="text-gray-600 mt-2">Connect your WhatsApp account to start automation</p>
      </div>

      <div className="max-w-2xl mx-auto">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <Phone className={status?.isConnected ? 'text-green-600' : 'text-gray-400'} size={32} />
              <div>
                <h2 className="text-xl font-semibold">
                  {status?.isConnected ? 'Connected' : 'Disconnected'}
                </h2>
                <p className="text-sm text-gray-600">
                  {status?.isConnected 
                    ? `Active as: ${status.phoneNumber}` 
                    : 'Scan QR code to connect'}
                </p>
              </div>
            </div>
            {status?.isConnected ? (
              <CheckCircle className="text-green-600" size={32} />
            ) : (
              <XCircle className="text-red-600" size={32} />
            )}
          </div>

          {!status?.isConnected && status?.qrCode && (
            <div className="border-t pt-6">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-4 text-center">Scan QR Code</h3>
                <div className="flex justify-center">
                  <img 
                    src={status.qrCode} 
                    alt="WhatsApp QR Code" 
                    className="w-64 h-64"
                  />
                </div>
                <div className="mt-4 space-y-2 text-sm text-gray-600">
                  <p className="flex items-start">
                    <span className="font-semibold mr-2">1.</span>
                    Open WhatsApp on your phone
                  </p>
                  <p className="flex items-start">
                    <span className="font-semibold mr-2">2.</span>
                    Tap Menu or Settings and select Linked Devices
                  </p>
                  <p className="flex items-start">
                    <span className="font-semibold mr-2">3.</span>
                    Tap on Link a Device
                  </p>
                  <p className="flex items-start">
                    <span className="font-semibold mr-2">4.</span>
                    Point your phone at this screen to scan the QR code
                  </p>
                </div>
              </div>
            </div>
          )}

          {!status?.isConnected && !status?.qrCode && (
            <div className="border-t pt-6">
              <div className="flex flex-col items-center justify-center py-12">
                <RefreshCw className="animate-spin text-primary-600 mb-4" size={48} />
                <p className="text-gray-600">Generating QR code...</p>
                <p className="text-sm text-gray-500 mt-2">Please wait a moment</p>
              </div>
            </div>
          )}

          {status?.isConnected && (
            <div className="border-t pt-6">
              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-green-900 mb-2">
                  ✓ WhatsApp Connected Successfully
                </h3>
                <p className="text-green-700">
                  Your WhatsApp is now connected and ready to receive messages. 
                  All incoming messages will be automatically processed by AI.
                </p>
                <div className="mt-4 space-y-1 text-sm text-green-700">
                  <p>📱 Phone: {status.phoneNumber}</p>
                  <p>🤖 AI Automation: Active</p>
                  <p>💬 Auto-Reply: Enabled</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
