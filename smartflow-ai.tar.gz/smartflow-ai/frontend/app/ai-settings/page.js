'use client';

import { useEffect, useState } from 'react';
import axios from 'axios';
import { Brain, Save, TestTube } from 'lucide-react';

export default function AISettingsPage() {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await axios.get('/api/ai-settings');
      setSettings(response.data);
    } catch (error) {
      console.error('Error fetching AI settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await axios.put(`/api/ai-settings/${settings.id}`, settings);
      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Error saving settings');
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    try {
      const response = await axios.post('/api/ai-settings/test', {
        provider: settings.provider,
        model: settings.model,
        apiKey: settings.apiKey === '***REDACTED***' ? undefined : settings.apiKey,
        testMessage: 'Hello, I am interested in your services'
      });
      setTestResult(response.data);
    } catch (error) {
      console.error('Error testing AI:', error);
      setTestResult({ success: false, error: error.message });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">AI Settings</h1>
        <p className="text-gray-600 mt-2">Configure AI provider and conversation behavior</p>
      </div>

      <div className="max-w-3xl">
        <form onSubmit={handleSave}>
          <div className="card mb-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Brain className="mr-2" size={20} />
              AI Provider Configuration
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  AI Provider
                </label>
                <select
                  value={settings?.provider || 'openai'}
                  onChange={(e) => setSettings({ ...settings, provider: e.target.value })}
                  className="input"
                >
                  <option value="openai">OpenAI</option>
                  <option value="gemini">Google Gemini</option>
                  <option value="openrouter">OpenRouter</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Model
                </label>
                <input
                  type="text"
                  value={settings?.model || ''}
                  onChange={(e) => setSettings({ ...settings, model: e.target.value })}
                  placeholder="gpt-3.5-turbo"
                  className="input"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Temperature
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="2"
                  value={settings?.temperature || 0.7}
                  onChange={(e) => setSettings({ ...settings, temperature: parseFloat(e.target.value) })}
                  className="input"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Higher values make responses more creative (0-2)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Max Tokens
                </label>
                <input
                  type="number"
                  value={settings?.maxTokens || 500}
                  onChange={(e) => setSettings({ ...settings, maxTokens: parseInt(e.target.value) })}
                  className="input"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Maximum response length
                </p>
              </div>
            </div>
          </div>

          <div className="card mb-6">
            <h3 className="text-lg font-semibold mb-4">
              System Prompt
            </h3>
            <textarea
              value={settings?.systemPrompt || ''}
              onChange={(e) => setSettings({ ...settings, systemPrompt: e.target.value })}
              rows={6}
              className="input font-mono text-sm"
              placeholder="Define how the AI should behave..."
            />
            <p className="text-sm text-gray-500 mt-2">
              This prompt defines the AI's personality and response style
            </p>
          </div>

          <div className="flex space-x-4">
            <button
              type="submit"
              disabled={saving}
              className="btn-primary flex items-center"
            >
              <Save className="mr-2" size={16} />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
            <button
              type="button"
              onClick={handleTest}
              className="btn-secondary flex items-center"
            >
              <TestTube className="mr-2" size={16} />
              Test AI
            </button>
          </div>
        </form>

        {testResult && (
          <div className={`card mt-6 ${testResult.success ? 'bg-green-50' : 'bg-red-50'}`}>
            <h4 className="font-semibold mb-2">
              {testResult.success ? 'Test Successful!' : 'Test Failed'}
            </h4>
            {testResult.success ? (
              <div>
                <p className="text-sm text-gray-600 mb-2">Test Message: {testResult.testMessage}</p>
                <div className="bg-white p-3 rounded border">
                  <p className="text-sm font-medium text-gray-700">AI Response:</p>
                  <p className="text-gray-900 mt-1">{testResult.aiResponse}</p>
                </div>
              </div>
            ) : (
              <p className="text-red-700">{testResult.error}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
