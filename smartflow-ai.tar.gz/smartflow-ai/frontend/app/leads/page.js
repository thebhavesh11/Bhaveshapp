'use client';

import { useEffect, useState } from 'react';
import axios from 'axios';
import { Search, Filter, User, Phone, Calendar } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function LeadsPage() {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchLeads();
  }, [filter, search]);

  const fetchLeads = async () => {
    try {
      const params = {};
      if (filter !== 'all') params.score = filter;
      if (search) params.search = search;
      
      const response = await axios.get('/api/leads', { params });
      setLeads(response.data.leads);
    } catch (error) {
      console.error('Error fetching leads:', error);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score) => {
    switch (score) {
      case 'HOT': return 'bg-red-100 text-red-700 border-red-200';
      case 'WARM': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'COLD': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'SPAM': return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'NEW': return 'bg-green-100 text-green-700';
      case 'CONTACTED': return 'bg-blue-100 text-blue-700';
      case 'QUALIFIED': return 'bg-purple-100 text-purple-700';
      case 'CONVERTED': return 'bg-teal-100 text-teal-700';
      case 'LOST': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Leads</h1>
        <p className="text-gray-600 mt-2">Manage and track your leads</p>
      </div>

      {/* Filters */}
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-2 flex-1 max-w-md">
            <Search className="text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search by phone or name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="text-gray-400" size={20} />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="input w-40"
            >
              <option value="all">All Leads</option>
              <option value="HOT">Hot</option>
              <option value="WARM">Warm</option>
              <option value="COLD">Cold</option>
              <option value="SPAM">Spam</option>
            </select>
          </div>
        </div>
      </div>

      {/* Leads List */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      ) : leads.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {leads.map((lead) => (
            <div key={lead.id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center">
                    <User size={24} className="text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {lead.name || 'Unknown'}
                    </h3>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <Phone size={14} className="mr-1" />
                      {lead.phoneNumber}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 mb-3">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getScoreColor(lead.leadScore)}`}>
                  {lead.leadScore}
                </span>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(lead.leadStatus)}`}>
                  {lead.leadStatus}
                </span>
              </div>

              {lead.conversations && lead.conversations.length > 0 && (
                <div className="text-sm text-gray-600 mb-2">
                  Last contact: {formatDistanceToNow(new Date(lead.conversations[0].lastMessageAt), { addSuffix: true })}
                </div>
              )}

              <div className="flex items-center text-xs text-gray-500">
                <Calendar size={12} className="mr-1" />
                Created {formatDistanceToNow(new Date(lead.createdAt), { addSuffix: true })}
              </div>

              <div className="mt-4 pt-4 border-t">
                <button className="w-full btn-primary text-sm">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center py-12">
          <User className="mx-auto text-gray-400 mb-4" size={48} />
          <p className="text-gray-600">No leads found</p>
          <p className="text-sm text-gray-500 mt-2">
            {search || filter !== 'all' 
              ? 'Try adjusting your filters' 
              : 'Leads will appear here when customers message you'}
          </p>
        </div>
      )}
    </div>
  );
}
