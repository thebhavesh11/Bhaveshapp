'use client';

import { useEffect, useState } from 'react';
import { MessageSquare, Users, TrendingUp, Activity, Phone } from 'lucide-react';
import axios from 'axios';
import MetricCard from '../components/dashboard/MetricCard';
import RecentActivity from '../components/dashboard/RecentActivity';
import LeadScoreChart from '../components/dashboard/LeadScoreChart';

export default function Dashboard() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [whatsappStatus, setWhatsappStatus] = useState(null);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      const [metricsRes, whatsappRes] = await Promise.all([
        axios.get('/api/dashboard/metrics'),
        axios.get('/api/whatsapp/status')
      ]);
      
      setMetrics(metricsRes.data);
      setWhatsappStatus(whatsappRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">Welcome to SmartFlow AI Automation Platform</p>
      </div>

      {/* WhatsApp Status Banner */}
      <div className={`mb-6 p-4 rounded-lg ${whatsappStatus?.isConnected ? 'bg-green-50 border border-green-200' : 'bg-yellow-50 border border-yellow-200'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Phone className={whatsappStatus?.isConnected ? 'text-green-600' : 'text-yellow-600'} size={24} />
            <div>
              <p className="font-semibold">
                {whatsappStatus?.isConnected ? 'WhatsApp Connected' : 'WhatsApp Disconnected'}
              </p>
              <p className="text-sm text-gray-600">
                {whatsappStatus?.isConnected 
                  ? `Connected as: ${whatsappStatus.phoneNumber}` 
                  : 'Please scan QR code to connect'}
              </p>
            </div>
          </div>
          {!whatsappStatus?.isConnected && (
            <a href="/whatsapp" className="btn-primary">
              Connect Now
            </a>
          )}
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Messages Today"
          value={metrics?.today?.totalMessages || 0}
          icon={MessageSquare}
          trend={`${metrics?.today?.messagesReceived || 0} received`}
          color="blue"
        />
        <MetricCard
          title="Leads Today"
          value={metrics?.today?.leadsCreated || 0}
          icon={Users}
          trend="New contacts"
          color="green"
        />
        <MetricCard
          title="Hot Leads"
          value={metrics?.overall?.hotLeads || 0}
          icon={TrendingUp}
          trend="High intent"
          color="red"
        />
        <MetricCard
          title="Active Conversations"
          value={metrics?.overall?.activeConversations || 0}
          icon={Activity}
          trend="Ongoing chats"
          color="purple"
        />
      </div>

      {/* Lead Distribution and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <LeadScoreChart 
          hot={metrics?.overall?.hotLeads || 0}
          warm={metrics?.overall?.warmLeads || 0}
          cold={metrics?.overall?.coldLeads || 0}
        />
        <RecentActivity 
          recentLeads={metrics?.recentActivity || []}
        />
      </div>
    </div>
  );
}
